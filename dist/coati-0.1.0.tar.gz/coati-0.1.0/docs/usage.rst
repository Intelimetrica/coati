=====
Usage
=====

To use coati in a project::

	import coati
