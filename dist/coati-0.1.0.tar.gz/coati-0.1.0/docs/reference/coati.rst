coati
=====

.. testsetup::

    from coati import *

.. automodule:: coati
    :members:
