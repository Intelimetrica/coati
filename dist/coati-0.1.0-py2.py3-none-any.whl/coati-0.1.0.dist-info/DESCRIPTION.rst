**coati** is a tool that provides a fast, simple and highly customizable  way to programmatically
generate PowerPoint presentations.
coati works using a base PowerPoint template and can replicate and fill the slides with the desire
information.

Currently coati supports four types of inputs:

 - Excel charts
 - Images (png, svg, jpg)
 - Excel tables
 - Text


