"""Custom exceptions classes"""


class CoatiException(Exception):
    pass


class CLIException(CoatiException):
    pass
